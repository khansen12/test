document.addEventListener("DOMContentLoaded", function () {
  // Initialize channel
  app.initialized().then(function(_client) {
    console.log("Initalzie");
    window.client = _client;
    // App activate callback
    client.instance.receive(function (event) {
      console.log("reciver");
      var data = event.helper.getData();
      document.getElementById('result').textContent = data.message;
    });
    const openModalButton = document.getElementById('openModalBtn');
    console.log("openModal function call");
    openModalButton.addEventListener('click', openModal);

  });
});


function submitFunction(){
  console.log("into submit function");
  var ticketVal = document.getElementById('fs-ticket');
  var hoursVal = document.getElementById('fs-hours');
  var dateVal = document.getElementById('fs-date');
  var notesVal = document.getElementById('fs-notes');
  var billableVal = document.getElementById('fs-billable');

  document.getElementById('result').textContent = ticketVal + hoursVal + dateVal + notesVal + billableVal;
  console.log("write text");
  client.instance.close();
  console.log("close modal");
}




function openModal(){
  console.log("Trigger modal");
  client.interface.trigger('showModal', {
    title: 'Enter Time',
    template: './views/timeLog.html'
  }).then(null, function () {
    client.interface.trigger('showNotify', {
      type: 'error',
      message: 'Some error has occured in \'Submit Time App\'.'
    });
  });
}
