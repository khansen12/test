document.addEventListener('DOMContentLoaded', function () {
    app.initialized().then(function (_client) {
        window._client = _client;
    });
});

function submitFunction() {
    console.log("Into submit function");
    var agent = q('#fs-ticket').value;
    var billable = q('#fs-billable').getAttribute('checked');
    var note = q('#fs-note').value;
    var hours =  q('#fs-hours').value;
    var date = q('#fs-date').value;
    console.log("Sending data");
    _client.instance.send({ message: { agent, billable, note, hours, date } });
    console.log("close modal");
    _client.instance.close();
    console.log("end submit");
}
